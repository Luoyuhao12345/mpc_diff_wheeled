#ifndef __UTIL_H_
#define __UTIL_H_

#include "my_planner/way_points.h"
#include </usr/local/include/eigen3/Eigen/Dense>

#define pi 3.14159

using namespace Eigen;

int find_match_point(my_planner::way_points ref_path, float car_x, float car_y);
float yaw2yaw(float yaw);
float rad2deg(float x);
VectorXd cal_traj(int Np, float T, float vel, int index, my_planner::way_points &ref_path);
void traj_process(float yaw, MatrixXd &traj);


#endif