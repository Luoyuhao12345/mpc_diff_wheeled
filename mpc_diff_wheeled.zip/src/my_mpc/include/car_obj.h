#ifndef CAR_OBJ_H
#define CAR_OBJ_H

#define CAR_L   0.3

class CarObj
{
public:
    CarObj();
    void set_expect_vel(float vel);
public:
    float x, y, yaw;
    float vr, vl;
    float vx, wz;
    float expt_vel;
};

#endif