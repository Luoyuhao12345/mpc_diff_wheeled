#ifndef __MPC_UTIL_H_
#define __MPC_UTIL_H_

#include <ros/ros.h>
#include <nav_msgs/Path.h>
#include <iostream>
#include </usr/local/include/eigen3/Eigen/Dense>
#include </usr/local/include/OsqpEigen/OsqpEigen.h>
#include "util.h"


#define CAR_L   0.3
#define pi 3.14159

using namespace std;

class MpcUtil 
{
public:
    MpcUtil();
    void update_matrix(float yaw);
    float* get_result(float car_x, float car_y, float car_yaw, Eigen::MatrixXd traj);
    void init_mat(float q, float r, int Np, float tt);

private:
    Eigen::MatrixXd _pow_2d(Eigen::MatrixXd X, int n);
    void _set_limit();
    void _set_A_I();
    void _init_Q_R(float q, float r);
    void _init_solver();
    void _traj_predict(Eigen::VectorXd pred, float car_x, float car_y, float car_yaw);

public:
    ros::Publisher traj_pred_pub;

private:
    OsqpEigen::Solver solver;
    // 调用osqp-eigen的标准矩阵
    Eigen::SparseMatrix<double> hessian;
    Eigen::VectorXd gradient;
    Eigen::SparseMatrix<double> linearMatrix;
    Eigen::VectorXd lowerBound;
    Eigen::VectorXd upperBound;
    // 方便自己使用的野矩阵
    Eigen::MatrixXd A;
    Eigen::MatrixXd B;
    Eigen::MatrixXd Q;
    Eigen::MatrixXd R;
    Eigen::MatrixXd Phi;
    Eigen::MatrixXd Theta;
    Eigen::MatrixXd A_I;
    Eigen::MatrixXd H;
    Eigen::VectorXd f;
    int Nx, Nu;
    float T;
    int horizon;
};


#endif