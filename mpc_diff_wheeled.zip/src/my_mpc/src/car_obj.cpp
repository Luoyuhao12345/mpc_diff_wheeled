#include "car_obj.h"


CarObj::CarObj()
{
    x = y = yaw = 0;
    vr = vl =0;
    vx = wz = 0;
    expt_vel = 0;
}

void CarObj::set_expect_vel(float vel)
{
    expt_vel = vel;
}
