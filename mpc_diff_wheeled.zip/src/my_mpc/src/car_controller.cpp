#include <ros/ros.h>
#include <geometry_msgs/Twist.h>
#include "my_mpc/car_info.h"
#include "my_planner/way_points.h"
#include "mpc_util.h"
#include "car_obj.h"
#include "util.h"


using namespace std;


bool receive_path = false;
my_planner::way_points ref_path;
MpcUtil mu = MpcUtil();
CarObj car_state = CarObj();
ros::Publisher cmd_pub;
// 需要调试的参数
float T;
float q, r;
int Np;
float expt_vel;


void control_cb(const ros::TimerEvent& event)
{
    if (!receive_path) return;
    int index = find_match_point(ref_path, car_state.x, car_state.y);
    mu.update_matrix(car_state.yaw);
    VectorXd ref_traj = cal_traj(Np, T, expt_vel, index, ref_path);
    geometry_msgs::Twist msg;
    float* result = mu.get_result(car_state.x, car_state.y, car_state.yaw, ref_traj);
    float vx, wz;
    vx = result[0];
    wz = result[1];
    delete[] result;
    msg.linear.x = vx;
    msg.angular.z = wz;
    cmd_pub.publish(msg);
    ROS_INFO("vx:%f, wz:%f", vx, wz);
}

void car_info_cb(const my_mpc::car_info::ConstPtr& msg)
{
    car_state.x = msg->car_x;
    car_state.y = msg->car_y;
    car_state.yaw = msg->car_yaw;
}

void ref_path_cb(const my_planner::way_points::ConstPtr& msg)
{
    ref_path = *msg;
    receive_path = true;
}


int main(int argc, char **argv)
{
    ros::init(argc, argv, "car_controller");
    ros::NodeHandle nh;

    cmd_pub = nh.advertise<geometry_msgs::Twist>("/cmd_vel", 1);
    ros::Subscriber car_info_sub = nh.subscribe("/car_info", 10, car_info_cb);
    ros::Subscriber path_sub = nh.subscribe("/ref_path", 10, ref_path_cb);

    nh.param("/car_controller/T", T, float(0.1));
    ros::Timer timer1 = nh.createTimer(ros::Duration(T), control_cb);

    // 调mpc参数
    nh.param("/car_controller/q", q, float(100));
    nh.param("/car_controller/r", r, float(20));
    nh.param("/car_controller/Np", Np, int(20));
    cout<<"q:"<<q<<", r:"<<r<<", Np: "<<Np<<endl;
    mu.init_mat(q,r,Np, T);
    mu.traj_pred_pub = nh.advertise<nav_msgs::Path>("/pred_path", 20);

    // 调小车速度
    nh.param("/car_controller/expt_vel", expt_vel, float(0.5));
    car_state.set_expect_vel(expt_vel);

    ros::spin();
    return 0;
}
