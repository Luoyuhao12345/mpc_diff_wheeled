#include "util.h"

using namespace std;


int find_match_point(my_planner::way_points ref_path, float car_x, float car_y)
{
    int n = ref_path.way_points.size();
    float min_dis = 99999;
    int index = 0;
    for (int i = 0; i < n; i++)
    {
        float x = ref_path.way_points[i].x;
        float y = ref_path.way_points[i].y;
        float cur_dis = sqrt(pow(car_x-x, 2)+pow(car_y-y, 2));
        if (cur_dis < min_dis)
        {
            min_dis = cur_dis;
            index = i;
        }
    }
    return index;
}


float yaw2yaw(float yaw)
{
    if(yaw >= pi*3/4) yaw -= 2*pi;
    if(yaw <= -pi*3/4) yaw += 2*pi;
    return yaw;
}

float rad2deg(float x)
{
    return x/pi*180;
}


VectorXd cal_traj(int Np, float T, float vel, int index, my_planner::way_points &ref_path)
{
    int Nx = 3;
    int Nu = 2;
    VectorXd ref_traj(Np*Nx);
    int n = ref_path.way_points.size();
    float d_s = T*vel;
    for(int i = 0; i<Np; i++)
    {
        int k = 3*i;
        if(index == n)
        {
            ref_traj(k) = ref_path.way_points[n-1].x;
            ref_traj(k+1) = ref_path.way_points[n-1].y;
            ref_traj(k+2) = ref_path.way_points[n-1].yaw;
        }
        else
        {
            for (int j = index; j < n; j++)
            {
                float x0 = ref_path.way_points[index].x;
                float y0 = ref_path.way_points[index].y;
                float x1 = ref_path.way_points[j].x;
                float y1 = ref_path.way_points[j].y;
                float cur_dis = sqrt(pow(x0-x1, 2)+pow(y0-y1, 2));
                if (cur_dis >= d_s)
                {
                    ref_traj(k) = ref_path.way_points[j].x;
                    ref_traj(k+1) = ref_path.way_points[j].y;
                    ref_traj(k+2) = ref_path.way_points[j].yaw;
                    index = j;
                    break;
                }
            }
        }
    }
    return ref_traj;
}

void traj_process(float yaw, MatrixXd &traj)
{
    int Nx = 3;
    // // 处理轨迹的角度
    int n = traj.rows();
    for(int i = 0; i<n; i += Nx)
    {
        if(traj(i+2) > pi)
            traj(i+2) -= 2*pi;
    }
    float e_yaw = 0;
    for(int i = 0; i<n; i += Nx)
    {
        e_yaw = yaw - traj(i+2);
        if(e_yaw < -pi)
            traj(i+2) -= 2*pi;
        if(e_yaw > pi)
            traj(i+2) += 2*pi;
    }
}
