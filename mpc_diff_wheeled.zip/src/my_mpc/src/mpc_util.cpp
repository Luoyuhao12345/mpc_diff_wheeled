#include "mpc_util.h"

using namespace Eigen;


MpcUtil::MpcUtil()
{
	Nx = 3;
	Nu = 2;
}

void MpcUtil::init_mat(float q, float r, int Np, float tt)
{
    T = tt;
	horizon = Np;
    A = MatrixXd::Identity(Nx, Nx);
	B = Matrix<double, 3, 2>::Zero();
	Phi.resize(Nx*horizon, Nx);
	Phi.setZero();
	Theta.resize(Nx*horizon, Nu*horizon);
	Theta.setZero();
	_set_limit();
	_set_A_I();
	_init_Q_R(q, r);
	_init_solver();
}

void MpcUtil::update_matrix(float yaw)
{
	B<<T*cos(yaw), 0,
			T*sin(yaw),  0,
			0,                      T;
	for (int i = 0; i < horizon; i++)
	{
		Phi.block(Nx*i, 0, Nx, Nx) = _pow_2d(A, i+1);
		for (int j = 0; j < horizon; j++)
		{
			if (i>=j)
			{
				Theta.block(Nx*i, Nu*j, Nx, Nu) = _pow_2d(A, i-j)*B;
			}
			else break;
		}
	}
}

float* MpcUtil::get_result(float car_x, float car_y, float car_yaw, Eigen::MatrixXd traj)
{
	Eigen::MatrixXd x;
	x.resize(3, 1);
	x << car_x, car_y, car_yaw;
	traj_process(car_yaw, traj);
	Eigen::MatrixXd E = Phi*x - traj;
	H = 2*(Theta.transpose()*Q*Theta+R);
	f = 2*Theta.transpose()*Q.transpose()*E;
	hessian = H.sparseView();
	gradient = f;
	linearMatrix = A_I.sparseView();
	solver.data()->setHessianMatrix(hessian);
	solver.data()->setGradient(gradient);
	solver.data()->setLinearConstraintsMatrix(linearMatrix);
	solver.data()->setLowerBound(lowerBound);
	solver.data()->setUpperBound(upperBound);
	solver.initSolver();
	solver.solveProblem();
	Eigen::VectorXd QPSolution;
	QPSolution = solver.getSolution();
	float* result = new float[2];
	result[0] = QPSolution[0];
	result[1] = QPSolution[1];
	solver.data()->clearHessianMatrix();
	solver.data()->clearLinearConstraintsMatrix();
	solver.clearSolver();
	_traj_predict(QPSolution, car_x, car_y, car_yaw);

	return result;
}

Eigen::MatrixXd MpcUtil::_pow_2d(Eigen::MatrixXd X, int n)
{
	Eigen::MatrixXd Y = Eigen::MatrixXd::Identity(Nx, Nx);
	for (int i = 0; i < n; i++)
	{
		Y = Y*X;
	}
	return Y;
}

void MpcUtil::_set_limit()
{
	upperBound.resize(Nu*horizon);
	lowerBound.resize(Nu*horizon);
	int n = Nu*horizon;
	// 速度约束
	for (int i = 0; i < Nu*horizon; i+=Nu)
	{
		upperBound(i) = 2;
		lowerBound(i) = 0;
		upperBound(i+1) = pi/3;
		lowerBound(i+1) = -pi/3;
	}
}

void MpcUtil::_set_A_I()
{
	A_I = Eigen::MatrixXd::Identity(horizon*Nu, horizon*Nu);
}

void MpcUtil::_init_Q_R(float q, float r)
{
	Q = Eigen::MatrixXd::Identity(Nx*horizon, Nx*horizon)*q;
	R = Eigen::MatrixXd::Identity(Nu*horizon, Nu*horizon)*r;
}

void MpcUtil::_init_solver()
{
	solver.settings()->setWarmStart(true);
	solver.settings()->setVerbosity(false);
	solver.data()->setNumberOfVariables(Nu*horizon);
    solver.data()->setNumberOfConstraints(Nu*horizon);
}

void MpcUtil::_traj_predict(Eigen::VectorXd pred, float car_x, float car_y, float car_yaw)
{
	nav_msgs::Path pred_path;
	pred_path.header.frame_id = "map";
	float pred_yaw = car_yaw;
	float pred_x = car_x;
	float pred_y = car_y;
	int n = pred.rows();
	for(int i = 0; i<n; i+=Nu)
	{
		float vx, wz;
		vx = pred(i, 0);
		wz = pred(i+1, 0);
		pred_yaw +=T*wz;
		pred_x += T*vx*cos(pred_yaw);
		pred_y += T*vx*sin(pred_yaw);
		geometry_msgs::PoseStamped pose;
		pose.pose.position.x = pred_x;
		pose.pose.position.y = pred_y;
		pred_path.poses.push_back(pose);
	}
	traj_pred_pub.publish(pred_path);
}